#pragma once

#include <iostream>
#include <vector>

#include "messageData.h"

extern std::vector<MessageData> messages;